package springLiquibase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLiquibaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
